from setuptools import setup



setup(
    name="xuancuong",
    version='0.0.1',
    license='Eclipse Public License 0.0.1',
    authors=["xuancuong", "loTus01", "BlueRed"],
    author_email="<xuancuongdev2006@gmail.com>",
    description="by xuancuong, loTus01 and BlueRed",
    keywords=['cli', 'fade', 'colors', 'terminal', 'tui'],
    packages=['xuancuong']
)
